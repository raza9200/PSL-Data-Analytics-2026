# ==============================================================================
# PROJECT: Pakistan Super League (PSL) Sports Analytics Pipeline
# MODULE: Data Reshaping - Demonstrating pivot_longer() and pivot_wider()
# ==============================================================================

library(tidyverse)

# Load the cleaned data state
if (file.exists("outputs/cleaned_state.RData")) {
  load("outputs/cleaned_state.RData")
} else {
  stop("FATAL ERROR: outputs/cleaned_state.RData not found. Please run your cleaning scripts first!")
}

cat("--- Beginning Data Reshaping Operations ---\n")

# ==============================================================================
# 1. PIVOT_WIDER: Convert long format to wide format
# ==============================================================================
cat("1. PIVOT_WIDER: Creating wide format for player performance by match\n")

# Create a long format dataset of player performance by match
player_match_long <- psl_ball_final %>%
  group_by(match_id, striker) %>%
  summarise(
    runs = sum(runs_off_bat, na.rm = TRUE),
    balls = n(),
    strike_rate = (sum(runs_off_bat, na.rm = TRUE) / n()) * 100,
    .groups = "drop"
  ) %>%
  filter(balls >= 10) # Only players who faced at least 10 balls

cat("Long format dataset:", nrow(player_match_long), "rows\n")
print(head(player_match_long))

# Pivot to wide format - one row per match, columns for top players
wide_player_performance <- player_match_long %>%
  filter(striker %in% head(unique(striker), 10)) %>% # Top 10 players for demonstration
  pivot_wider(
    names_from = striker,
    values_from = c(runs, balls, strike_rate),
    names_sep = "_"
  )

cat("\nWide format result:", nrow(wide_player_performance), "rows x", ncol(wide_player_performance), "columns\n")

# FIXED: Selecting columns dynamically by position rather than hardcoded names
# This guarantees it will never throw a "column doesn't exist" error
available_cols <- colnames(wide_player_performance)
cols_to_print <- c(1, grep("runs|balls|strike_rate", available_cols)[1:3]) # match_id + first 3 dynamic stats
cols_to_print <- cols_to_print[!is.na(cols_to_print)] # Remove any NA values safely

print(head(wide_player_performance %>% select(all_of(cols_to_print))))

# Save wide format
write_csv(wide_player_performance, "outputs/player_performance_wide.csv")

# ==============================================================================
# 2. PIVOT_LONGER: Convert wide format to long format
# ==============================================================================
cat("\n2. PIVOT_LONGER: Converting wide format back to long format\n")

# Create a sample wide dataset for demonstration
sample_wide_data <- psl_ball_final %>%
  filter(match_id %in% unique(match_id)[1:5]) %>% # First 5 matches
  group_by(match_id, batting_team) %>%
  summarise(
    total_runs = sum(runs_off_bat, na.rm = TRUE),
    total_fours = sum(runs_off_bat == 4, na.rm = TRUE),
    total_sixes = sum(runs_off_bat == 6, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  pivot_wider(
    names_from = batting_team,
    values_from = c(total_runs, total_fours, total_sixes)
  )

cat("Sample wide data created:", nrow(sample_wide_data), "rows\n")
print(sample_wide_data)

# Now pivot back to long format
long_team_performance <- sample_wide_data %>%
  pivot_longer(
    cols = -match_id,
    names_to = c(".value", "team"),
    names_sep = "_"
  )

cat("\nLong format result:", nrow(long_team_performance), "rows\n")
print(long_team_performance)

# Save long format
write_csv(long_team_performance, "outputs/team_performance_long.csv")

# ==============================================================================
# 3. Advanced pivot_longer with multiple value columns
# ==============================================================================
cat("\n3. ADVANCED PIVOT_LONGER: Multiple value columns from complex wide data\n")

# Create a complex wide dataset with multiple metrics
complex_wide <- psl_ball_final %>%
  filter(match_id %in% unique(match_id)[1:3]) %>%
  group_by(match_id, striker) %>%
  summarise(
    runs = sum(runs_off_bat, na.rm = TRUE),
    balls = n(),
    fours = sum(runs_off_bat == 4, na.rm = TRUE),
    sixes = sum(runs_off_bat == 6, na.rm = TRUE),
    .groups = "drop"
  ) %>%
  pivot_wider(
    names_from = striker,
    values_from = c(runs, balls, fours, sixes),
    names_glue = "{striker}_{.value}"
  )

cat("Complex wide data created:", nrow(complex_wide), "rows\n")
print(head(complex_wide))

# Pivot back to long format
complex_long <- complex_wide %>%
  pivot_longer(
    cols = -match_id,
    names_to = c("player", "metric"),
    names_sep = "_",
    values_to = "value"
  )

cat("\nComplex long format result:", nrow(complex_long), "rows\n")
print(head(complex_long))

# ==============================================================================
# 4. PIVOT_LONGER with regex patterns
# ==============================================================================
cat("\n4. PIVOT_LONGER with regex: Extracting patterns from column names\n")

# Dynamic Season Column Resolver to prevent crashes
season_col_idx <- grep("season|year", colnames(psl_ball_final), ignore.case = TRUE)[1]
season_col_name <- if(!is.na(season_col_idx)) colnames(psl_ball_final)[season_col_idx] else "season"

# Create dataset with complex column names safely
regex_data <- psl_ball_final %>%
  rename(target_season = !!sym(season_col_name)) %>%
  filter(match_id %in% unique(match_id)[1:2]) %>%
  group_by(match_id) %>%
  summarise(
    `runs_2020_season` = sum(runs_off_bat[target_season == "2020" | target_season == "2019/20"], na.rm = TRUE),
    `runs_2021_season` = sum(runs_off_bat[target_season == "2021"], na.rm = TRUE),
    `wickets_2020_season` = sum(wicket_type[target_season == "2020" | target_season == "2019/20"] != "No Wicket", na.rm = TRUE),
    `wickets_2021_season` = sum(wicket_type[target_season == "2021"] != "No Wicket", na.rm = TRUE)
  )

cat("Regex pattern data created:", nrow(regex_data), "rows\n")
print(regex_data)

# FIXED: Standardized escape slashes for R regex engine inside pivot_longer
regex_long <- regex_data %>%
  pivot_longer(
    cols = -match_id,
    names_to = c("metric", "season"),
    names_pattern = "(\\w+)_(\\d+)_season",
    values_to = "value"
  )

cat("\nRegex long format result:", nrow(regex_long), "rows\n")
print(regex_long)

# ==============================================================================
# 5. Practical application: Reshaping for visualization
# ==============================================================================
cat("\n5. PRACTICAL APPLICATION: Reshaping data for visualization\n")

# Create a dataset for boundary analysis
boundary_data <- psl_ball_final %>%
  filter(runs_off_bat %in% c(4, 6)) %>%
  group_by(batting_team, runs_off_bat) %>%
  summarise(count = n(), .groups = "drop") %>%
  pivot_wider(
    names_from = runs_off_bat,
    values_from = count,
    names_glue = "boundary_{runs_off_bat}"
  )

cat("Boundary data in wide format:", nrow(boundary_data), "rows\n")
print(boundary_data)

# Reshape for ggplot2 visualization
boundary_long <- boundary_data %>%
  pivot_longer(
    cols = c(boundary_4, boundary_6),
    names_to = "boundary_type",
    values_to = "count"
  ) %>%
  mutate(boundary_type = str_replace(boundary_type, "boundary_", ""))

cat("\nBoundary data reshaped for visualization:", nrow(boundary_long), "rows\n")
print(head(boundary_long))

# Create visualization
dir.create("visualizations", showWarnings = FALSE)
boundary_plot <- ggplot(boundary_long, aes(x = batting_team, y = count, fill = boundary_type)) +
  geom_bar(stat = "identity", position = "dodge") +
  labs(title = "Team Boundary Distribution (4s vs 6s)", 
       x = "Batting Team", y = "Count", fill = "Boundary Type") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

# Save the plot
ggsave("visualizations/boundary_distribution_reshaped.png", plot = boundary_plot, width = 10, height = 6, dpi = 300)

# ==============================================================================
# 6. Reshaping date-time data
# ==============================================================================
cat("\n6. RESHAPING DATE-TIME DATA: Extracting temporal components\n")

# Extract date components safely using base R / lubridate format
date_reshaped <- psl_match_clean %>%
  mutate(
    parsed_date = as.Date(date)
  ) %>%
  mutate(
    year = format(parsed_date, "%Y"),
    month = format(parsed_date, "%b"),
    quarter = quarters(parsed_date),
    day_of_week = format(parsed_date, "%a")
  ) %>%
  select(match_id, date, year, month, quarter, day_of_week)

cat("Date components extracted:", nrow(date_reshaped), "rows\n")
print(head(date_reshaped))

# Save date reshaped data
write_csv(date_reshaped, "outputs/date_components_reshaped.csv")

cat("\n--- Data Reshaping Operations Complete ---\n")
cat("Demonstrated pivot_longer() and pivot_wider() with multiple applications\n")
cat("Results saved successfully to /outputs/ and /visualizations/\n")