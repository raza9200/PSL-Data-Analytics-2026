# ==============================================================================
# PROJECT: Pakistan Super League (PSL) Sports Analytics Pipeline
# MODULE: Enhanced Data Wrangling - 5 Filters, 5 New Variables, Categorical Recoding
# ==============================================================================

library(tidyverse)

# Load the cleaned data state
if (file.exists("outputs/cleaned_state.RData")) {
  load("outputs/cleaned_state.RData")
} else {
  stop("FATAL ERROR: outputs/cleaned_state.RData not found. Please run your cleaning scripts first!")
}

cat("--- Beginning Enhanced Data Wrangling Operations ---\n")

# ==============================================================================
# 1. DATA UNDERSTANDING AND QUALITY ASSESSMENT
# ==============================================================================
cat("1. Data Understanding and Quality Assessment\n")

# Check missing values
data_quality_report <- psl_ball_final %>%
  summarise(across(everything(), ~ sum(is.na(.)))) %>%
  pivot_longer(everything(), names_to = "column", values_to = "missing_count") %>%
  filter(missing_count > 0) %>%
  arrange(desc(missing_count))

cat("Missing values by column:\n")
print(data_quality_report)

# Check duplicates
duplicate_count <- psl_ball_final %>%
  count() %>%
  pull(n) - n_distinct(psl_ball_final)

cat("\nDuplicate rows found:", duplicate_count, "\n")

# Check unique values in categorical columns
categorical_summary <- psl_ball_final %>%
  select(where(is.character)) %>%
  summarise(across(everything(), ~ n_distinct(.)))

cat("Unique values in categorical columns:\n")
print(categorical_summary)

# ==============================================================================
# 2. FIVE MEANINGFUL FILTERS
# ==============================================================================
cat("\n2. Applying Five Meaningful Filters\n")

# Filter 1: High-scoring balls (4 or 6 runs)
high_scoring_balls <- psl_ball_final %>%
  filter(runs_off_bat %in% c(4, 6))

cat("Filter 1 - High scoring balls (4s and 6s):", nrow(high_scoring_balls), "records\n")

# Filter 2: Wickets taken (excluding "No Wicket")
wicket_balls <- psl_ball_final %>%
  filter(wicket_type != "No Wicket" & !is.na(wicket_type) & wicket_type != "None")

cat("Filter 2 - Wicket balls:", nrow(wicket_balls), "records\n")

# Filter 3: Powerplay overs (first 6 overs)
powerplay_balls <- psl_ball_final %>%
  filter(ball <= 36) # First 6 overs = 36 balls

cat("Filter 3 - Powerplay balls (first 6 overs):", nrow(powerplay_balls), "records\n")

# Filter 4: Death overs (last 5 overs)
death_over_balls <- psl_ball_final %>%
  filter(ball > 150 & ball <= 180) # Last 5 overs

cat("Filter 4 - Death over balls (last 5 overs):", nrow(death_over_balls), "records\n")

# Filter 5: Top performers (players with 50+ runs in a match)
top_performer_balls <- psl_ball_final %>%
  group_by(match_id, striker) %>%
  mutate(player_match_runs = sum(runs_off_bat, na.rm = TRUE)) %>%
  filter(player_match_runs >= 50) %>%
  ungroup()

cat("Filter 5 - Top performer balls (50+ runs in match):", nrow(top_performer_balls), "records\n")

# ==============================================================================
# 3. FIVE NEW VARIABLES
# ==============================================================================
cat("\n3. Creating Five New Variables\n")

enhanced_data <- psl_ball_final %>%
  mutate(
    # New Variable 1: Boundary indicator (1 if 4 or 6, 0 otherwise)
    is_boundary = ifelse(runs_off_bat %in% c(4, 6), 1, 0),
    
    # New Variable 2: Run rate per over at this ball
    current_run_rate = ifelse(ball > 0, (cumsum(runs_off_bat + extras) / (ball / 6)), 0),
    
    # New Variable 3: Over number (1-based)
    over_number = ceiling(ball / 6),
    
    # New Variable 4: Ball in over (1-6)
    ball_in_over = ((ball - 1) %% 6) + 1,
    
    # New Variable 5: Performance score (runs + wicket value)
    performance_score = runs_off_bat + ifelse(wicket_type != "No Wicket" & !is.na(wicket_type) & wicket_type != "None", 10, 0)
  )

cat("New variables created:\n")
print(head(enhanced_data %>% select(is_boundary, current_run_rate, over_number, ball_in_over, performance_score)))

# ==============================================================================
# 4. CATEGORICAL RECODING
# ==============================================================================
cat("\n4. Categorical Recoding\n")

enhanced_data <- enhanced_data %>%
  mutate(
    # Recode wicket types
    wicket_category = case_when(
      is.na(wicket_type) | wicket_type %in% c("No Wicket", "None") ~ "No Wicket",
      str_detect(tolower(wicket_type), "bowled") ~ "Bowled",
      str_detect(tolower(wicket_type), "caught") ~ "Caught",
      str_detect(tolower(wicket_type), "lbw") ~ "LBW",
      str_detect(tolower(wicket_type), "stumped") ~ "Stumped",
      str_detect(tolower(wicket_type), "run out") ~ "Run Out",
      TRUE ~ "Other"
    ),
    
    # FIXED: Replaced non-existent 'strike_rate' with 'current_run_rate' to represent score velocity categorization safely
    scoring_velocity_category = case_when(
      current_run_rate >= 9.0 ~ "High (>9.0 RPO)",
      current_run_rate >= 7.5 ~ "Standard (7.5-9.0 RPO)",
      current_run_rate >= 6.0 ~ "Moderate (6.0-7.5 RPO)",
      TRUE ~ "Low (<6.0 RPO)"
    ),
    
    # Recode teams into regions
    team_region = case_when(
      str_detect(tolower(batting_team), "karachi") ~ "Sindh",
      str_detect(tolower(batting_team), "lahore") ~ "Punjab",
      str_detect(tolower(batting_team), "islamabad") ~ "Federal",
      str_detect(tolower(batting_team), "peshawar") ~ "KPK",
      str_detect(tolower(batting_team), "quetta") ~ "Balochistan",
      str_detect(tolower(batting_team), "multan") ~ "Punjab",
      TRUE ~ "Other"
    )
  )

cat("Categorical recoding applied:\n")
print(head(enhanced_data %>% select(wicket_type, wicket_category, scoring_velocity_category, team_region)))

# ==============================================================================
# 5. MISSING DATA HANDLING WITH JUSTIFICATION
# ==============================================================================
cat("\n5. Missing Data Handling with Justification\n")

# Check missing values before handling
missing_before <- enhanced_data %>%
  summarise(across(everything(), ~ sum(is.na(.)))) %>%
  pivot_longer(everything(), names_to = "column", values_to = "missing_count") %>%
  filter(missing_count > 0)

cat("Missing values before handling:\n")
print(missing_before)

# Apply justified missing data handling strategies
enhanced_data_cleaned <- enhanced_data %>%
  mutate(
    wicket_type = ifelse(is.na(wicket_type), "No Wicket", wicket_type),
    player_dismissed = ifelse(is.na(player_dismissed), "None", player_dismissed),
    bowler = ifelse(is.na(bowler), "Unknown", bowler),
    extras = ifelse(is.na(extras), 0, extras)
  )

# Dynamic Season Column Fallback Strategy
season_idx <- grep("season|year", colnames(enhanced_data_cleaned), ignore.case = TRUE)[1]
if(!is.na(season_idx)) {
  season_col_name <- colnames(enhanced_data_cleaned)[season_idx]
  enhanced_data_cleaned <- enhanced_data_cleaned %>%
    mutate(season = ifelse(is.na(!!sym(season_col_name)), "2026", as.character(!!sym(season_col_name))))
} else {
  enhanced_data_cleaned$season <- "2026"
}

# Check missing values after handling
missing_after <- enhanced_data_cleaned %>%
  summarise(across(everything(), ~ sum(is.na(.)))) %>%
  pivot_longer(everything(), names_to = "column", values_to = "missing_count") %>%
  filter(missing_count > 0)

cat("\nMissing values after handling:\n")
if (nrow(missing_after) > 0) {
  print(missing_after)
} else {
  cat("No missing values remain after handling!\n")
}

# ==============================================================================
# 6. OUTLIER DETECTION AND HANDLING
# ==============================================================================
cat("\n6. Outlier Detection and Handling\n")

# Detect outliers in runs_off_bat using IQR method
runs_stats <- enhanced_data_cleaned %>%
  summarise(
    q1 = quantile(runs_off_bat, 0.25, na.rm = TRUE),
    q3 = quantile(runs_off_bat, 0.75, na.rm = TRUE),
    iqr = q3 - q1,
    lower_bound = q1 - 1.5 * iqr,
    upper_bound = q3 + 1.5 * iqr
  )

cat("Runs off bat statistics:\n")
print(runs_stats)

# Count outliers
outlier_count <- enhanced_data_cleaned %>%
  filter(runs_off_bat < runs_stats$lower_bound | runs_off_bat > runs_stats$upper_bound) %>%
  nrow()

cat("\nOutliers detected in runs_off_bat:", outlier_count, "\n")

# Handle outliers safely by winsorizing (capping at 99th percentile)
max_runs <- quantile(enhanced_data_cleaned$runs_off_bat, 0.99, na.rm = TRUE)
enhanced_data_cleaned <- enhanced_data_cleaned %>%
  mutate(
    runs_off_bat = ifelse(runs_off_bat > max_runs, max_runs, runs_off_bat)
  )

# ==============================================================================
# 7. DATA CONSISTENCY CHECKS
# ==============================================================================
cat("\n7. Data Consistency Checks\n")

# Check for inconsistent records
inconsistent_records <- enhanced_data_cleaned %>%
  filter(ball <= 0 | runs_off_bat < 0 | extras < 0)

cat("Inconsistent records found:", nrow(inconsistent_records), "\n")

# Fix inconsistencies
enhanced_data_cleaned <- enhanced_data_cleaned %>%
  mutate(
    ball = ifelse(ball <= 0, 1, ball),
    runs_off_bat = ifelse(runs_off_bat < 0, 0, runs_off_bat),
    extras = ifelse(extras < 0, 0, extras)
  )

# ==============================================================================
# 8. CREATE FINAL CLEANED DATASET
# ==============================================================================
cat("\n8. Creating Final Cleaned Dataset\n")

# STEP 1: Pehle calculation 'mutate' ke andar karein
enhanced_data_cleaned <- enhanced_data_cleaned %>%
  mutate(total_runs = runs_off_bat + extras)

# STEP 2: Ab 'select' ko sirf columns arrange karne ke liye istemal karein
final_cleaned_dataset <- enhanced_data_cleaned %>%
  select(
    match_id, ball, over_number, ball_in_over,
    batting_team, bowling_team,
    striker, non_striker, bowler,
    runs_off_bat, extras, total_runs,   # <-- Ab yeh smoothly select ho jayega
    is_boundary, performance_score,
    wicket_type, wicket_category, player_dismissed,
    season, team_region, scoring_velocity_category, current_run_rate
  )

cat("Final cleaned dataset rows:", nrow(final_cleaned_dataset), "\n")
print(head(final_cleaned_dataset))

# Save final cleaned dataset
write_csv(final_cleaned_dataset, "outputs/final_cleaned_psl_dataset.csv")

# ==============================================================================
# 9. DATA WRANGLING SUMMARY REPORT
# ==============================================================================
cat("\n9. Generating Data Wrangling Summary Report\n")

data_wrangling_summary <- tibble(
  operation = c(
    "Meaningful Filters Applied",
    "New Variables Created",
    "Categorical Recoding",
    "Missing Data Handled",
    "Outliers Detected & Handled",
    "Inconsistent Records Fixed"
  ),
  count = c(
    5, 5, 3, nrow(missing_before), outlier_count, nrow(inconsistent_records)
  ),
  description = c(
    "Applied 5 meaningful filters: high-scoring balls, wickets, powerplay, death overs, top performers",
    "Created 5 new variables: is_boundary, current_run_rate, over_number, ball_in_over, performance_score",
    "Recoded wicket types, scoring velocity categories, and team regions",
    "Handled missing values with justified strategies for each column type",
    "Detected and winsorized outliers in runs_off_bat using IQR method",
    "Fixed data inconsistencies in balls, runs, and extras fields"
  )
)

print(data_wrangling_summary)
write_csv(data_wrangling_summary, "outputs/data_wrangling_summary.csv")

# ==============================================================================
# 10. ENHANCED DATA VISUALIZATION
# ==============================================================================
cat("\n10. Creating Enhanced Visualizations from Wrangled Data\n")
dir.create("visualizations", showWarnings = FALSE)

# Visualization 1: Boundary distribution by over
boundary_by_over <- final_cleaned_dataset %>%
  filter(is_boundary == 1) %>%
  group_by(over_number) %>%
  summarise(boundary_count = n(), .groups = "drop")

boundary_plot <- ggplot(boundary_by_over, aes(x = over_number, y = boundary_count)) +
  geom_bar(stat = "identity", fill = "#1a365d") +
  labs(title = "Boundary Distribution by Over", x = "Over Number", y = "Boundary Count") +
  theme_minimal()
ggsave("visualizations/enhanced_boundary_by_over.png", plot = boundary_plot, width = 10, height = 6, dpi = 300)

# Visualization 2: Wicket types distribution
wicket_distribution <- final_cleaned_dataset %>%
  filter(wicket_category != "No Wicket") %>%
  group_by(wicket_category) %>%
  summarise(count = n(), .groups = "drop")

wicket_plot <- ggplot(wicket_distribution, aes(x = reorder(wicket_category, count), y = count)) +
  geom_bar(stat = "identity", fill = "#2b6cb0") +
  coord_flip() +
  labs(title = "Wicket Types Distribution (Recoded)", x = "Wicket Category", y = "Count") +
  theme_minimal()
ggsave("visualizations/enhanced_wicket_distribution.png", plot = wicket_plot, width = 8, height = 6, dpi = 300)

# Visualization 3: Performance score by team
team_performance_score <- final_cleaned_dataset %>%
  group_by(batting_team) %>%
  summarise(avg_performance_score = mean(performance_score, na.rm = TRUE), .groups = "drop")

performance_plot <- ggplot(team_performance_score, aes(x = reorder(batting_team, avg_performance_score), y = avg_performance_score)) +
  geom_bar(stat = "identity", fill = "#2c5282") +
  coord_flip() +
  labs(title = "Average Performance Score by Team", x = "Batting Team", y = "Average Performance Score") +
  theme_minimal()
ggsave("visualizations/enhanced_team_performance.png", plot = performance_plot, width = 8, height = 6, dpi = 300)

cat("\n--- Enhanced Data Wrangling Operations Complete ---\n")