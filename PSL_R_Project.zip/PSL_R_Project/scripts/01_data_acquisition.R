# ==============================================================================
# PROJECT: Pakistan Super League (PSL) Sports Analytics Pipeline
# COURSE: Exploratory Data Analysis 
# MODULE: Direct Ingestion & Column Repair (Fixed Directory & Single-File Path)
# ==============================================================================

library(tidyverse)
library(lubridate)

cat("--- Beginning Phase 2: Consolidated Data Processing Pipeline ---\n")

# 1. PATH CONFIGURATION
# R looks for paths relative to your active working directory.
# Since your root folder is "PSL_R_Project", this cleanly targets your data folder.
master_file_path <- "raw_data/all_matches.csv" 

# Fail-Safe Check: If the file is missing or R is in the wrong directory, it alerts you
if (!file.exists(master_file_path)) {
  stop(paste(
    "FATAL ERROR: Could not find master file at:", master_file_path,
    "\nYour current R Working Directory is:", getwd(),
    "\n\n[TROUBLESHOOTING TIPS]:",
    "\n1. Ensure 'all_matches.csv' is saved inside the 'raw_data' folder.",
    "\n2. In RStudio, go to Session -> Set Working Directory -> To Project Directory."
  ))
}

cat("📁 Integrity Check Passed. Reading master dataset directly...\n")
raw_dataset <- read_csv(master_file_path, col_types = cols(.default = "c"), show_col_types = FALSE)

# ------------------------------------------------------------------------------
# PHASE 3: SCHEMA STANDARDIZATION & TYPE-SAFETY CASTING
# ------------------------------------------------------------------------------
cat("\n--- Running Schema Standardization & Explicit Cast Transformation ---\n")

# Convert all column headers dynamically to snake_case to prevent formatting issues
psl_master_raw <- raw_dataset %>% rename_with(~ str_to_lower(str_replace_all(., " ", "_")))

# A. Isolate and Clean Ball-by-Ball Analytics Stream
psl_ball_final <- psl_master_raw %>%
  # Select standard match gameplay metrics, ignoring non-cricket data like player pricing
  select(match_id, season, start_date, venue, ball, innings, batting_team, bowling_team, 
         striker, non_striker, bowler, runs_off_bat, extras, wides, noballs, byes, legbyes, 
         wicket_type, player_dismissed) %>%
  mutate(
    match_id         = as.numeric(match_id),
    ball             = as.numeric(ball),
    runs_off_bat     = as.numeric(if_else(is.na(runs_off_bat) | runs_off_bat == "NA", "0", runs_off_bat)),
    extras           = as.numeric(if_else(is.na(extras) | extras == "NA", "0", extras)),
    wicket_type      = if_else(is.na(wicket_type), "No Wicket", wicket_type),
    player_dismissed = if_else(is.na(player_dismissed), "None", player_dismissed)
  ) %>% 
  distinct() # Strict Deduplication Layer to protect math metrics

# B. Isolate and Clean Match Summary Metadata Stream
psl_match_clean <- psl_master_raw %>%
  select(match_id, season, date = start_date, venue) %>%
  mutate(match_id = as.numeric(match_id)) %>%
  distinct() %>%
  mutate(
    venue = if_else(is.na(venue) | venue == "", "Unknown PSL Stadium", venue)
  )

# ------------------------------------------------------------------------------
# PHASE 4: COMPILE MASTER INTEGRATED DATASET & GENERATE KPIS
# ------------------------------------------------------------------------------
cat("\n--- Generating Clean Database Configurations & Analytics Environment ---\n")

# Combine datasets cleanly via match_id boundary
psl_master_clean <- psl_ball_final %>%
  inner_join(psl_match_clean, by = "match_id")

# Generate High-Value Batsmen KPI Performance Metrics (Feeds Plot engines downstream)
batsman_kpi_metrics <- psl_ball_final %>%
  group_by(striker) %>%
  summarise(
    total_runs = sum(runs_off_bat, na.rm = TRUE),
    balls_faced = n(),
    total_sixes = sum(runs_off_bat == 6, na.rm = TRUE),
    strike_rate = (total_runs / balls_faced) * 100,
    .groups = "drop"
  ) %>%
  filter(balls_faced >= 100) # Outlier noise filter to clear low-volume players

# Create outputs directory safely if it doesn't exist
if(!dir.exists("outputs")) {
  dir.create("outputs")
}

# Save complete clean environmental state so subsequent files read this exact model
save(psl_ball_final, psl_match_clean, psl_master_clean, batsman_kpi_metrics, file = "outputs/cleaned_state.RData")

# Summary Print Diagnostics
print(paste("✅ SUCCESS: Ball-by-Ball Layout Matrix - Rows:", nrow(psl_ball_final), "| Columns:", ncol(psl_ball_final)))
print(paste("✅ SUCCESS: Metadata Records Processed:", nrow(psl_match_clean)))
print(paste("✅ SUCCESS: Master Integrated Combined Elements:", nrow(psl_master_clean)))

cat("\n--- Integrity Check (Runs Distribution Metrics Summary) ---\n")
print(summary(psl_ball_final$runs_off_bat))