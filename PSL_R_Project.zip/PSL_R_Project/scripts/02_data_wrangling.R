# ==============================================================================
# PROJECT: Pakistan Super League (PSL) Sports Analytics Pipeline
# MODULE: Advanced Data Wrangling & Feature Engineering (Phase 5)
# ==============================================================================

library(tidyverse)

if (!exists("psl_ball_final") || !exists("psl_match_clean")) {
  stop("FATAL ERROR: Ingested master models not found. Kindly run script 01 first!")
}

cat("--- Beginning Phase 5: Executing Multi-Tier Summarization Engines ---\n")

# 1. Batsman Performance Profiles Matrix
batsman_kpi_metrics <- psl_ball_final %>%
  group_by(striker) %>%
  summarise(
    total_runs   = sum(runs_off_bat, na.rm = TRUE),
    balls_faced  = n(),
    total_sixes  = sum(runs_off_bat == 6, na.rm = TRUE),
    total_fours  = sum(runs_off_bat == 4, na.rm = TRUE),
    .groups      = "drop"
  ) %>%
  filter(balls_faced >= 100) %>%
  mutate(
    strike_rate = round((total_runs / balls_faced) * 100, 2)
  ) %>%
  arrange(desc(total_runs))

cat("\n==================================================================\n")
cat("               TOP 10 RUN-SCORERS IN PSL HISTORY (AUDITED)        \n")
cat("==================================================================\n")
print(head(batsman_kpi_metrics, 10))
write_csv(batsman_kpi_metrics, "outputs/engineered_batsmen_summary.csv")

# 2. Team Performance Analytics Profiles
cat("\n==================================================================\n")
cat("                 TEAM-LEVEL HISTORICAL SCORING METRICS            \n")
cat("==================================================================\n")
team_profile <- psl_ball_final %>%
  group_by(batting_team) %>%
  summarise(
    total_team_runs = sum(runs_off_bat + extras, na.rm = TRUE),
    total_balls_faced = n(),
    average_run_per_over = round(mean(runs_off_bat + extras, na.rm = TRUE) * 6, 2),
    .groups = "drop"
  ) %>%
  arrange(desc(total_team_runs))

print(team_profile)
write_csv(team_profile, "outputs/engineered_team_scoring_summary.csv")

# 3. Match Winner & Ground Density Matrices
cat("\n==================================================================\n")
cat("                MATCH SUMMARY METRICS: LEADERBOARDS               \n")
cat("==================================================================\n")

match_cols <- colnames(psl_match_clean)
winner_col <- if("winner" %in% match_cols) "winner" else NA
venue_col  <- if("venue" %in% match_cols) "venue" else NA

if (!is.na(winner_col)) {
  cat("--- Team Leaderboard by Match Victories ---\n")
  team_wins <- psl_match_clean %>%
    filter(!is.na(winner)) %>%
    group_by(winner) %>%
    summarise(total_wins = n(), .groups = "drop") %>%
    arrange(desc(total_wins))
  print(team_wins)
  write_csv(team_wins, "outputs/engineered_team_wins.csv")
}

if (!is.na(venue_col)) {
  cat("\n--- Venue Deployment Density Matrix ---\n")
  venue_density <- psl_match_clean %>%
    filter(!is.na(venue)) %>%
    group_by(venue) %>%
    summarise(matches_hosted = n(), .groups = "drop") %>%
    arrange(desc(matches_hosted))
  print(venue_density)
  write_csv(venue_density, "outputs/engineered_venue_density.csv")
}

print("STATUS: Full Phase 5 Engine executed perfectly with structured datasets serialized to disk.")