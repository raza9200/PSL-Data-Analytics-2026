# ==============================================================================
# PROJECT: Pakistan Super League (PSL) Sports Analytics Pipeline
# MODULE: Hypothesis Testing & Inferential Modeling (Phases 8 & 9)
# ==============================================================================

# ------------------------------------------------------------------------------
# STEP 1: Verification of Global Data Frame State
# ------------------------------------------------------------------------------
library(tidyverse)

if (!exists("batsman_kpi_metrics")) {
  stop("FATAL ERROR: Inherited dataset 'batsman_kpi_metrics' missing from current session.")
}

cat("--- Beginning Phase 8 & 9: Inferential Regression Engine ---\n")

# ------------------------------------------------------------------------------
# STEP 2: Execute Simple Linear Regression Modeling
# ------------------------------------------------------------------------------
# Fit a linear model predicting strike rate based on aggregate runs
performance_model <- lm(strike_rate ~ total_runs, data = batsman_kpi_metrics)

# Extract full model summary metrics
model_summary <- summary(performance_model)

# ------------------------------------------------------------------------------
# STEP 3: Automated Textual Extraction of Key Statistical Metrics
# ------------------------------------------------------------------------------
p_value   <- model_summary$coefficients[2, 4]
r_squared <- model_summary$r.squared
t_stat    <- model_summary$coefficients[2, 3]

cat("\n==================================================================\n")
cat("                PHASE 8 & 9: REGRESSION MODEL SUMMARY             \n")
cat("==================================================================\n")
print(model_summary)

cat("\n==================================================================\n")
cat("                     HYPOTHESIS TESTING VERDICT                   \n")
cat("==================================================================\n")
cat(paste("P-Value calculated by OLS Engine :", format.pval(p_value, digits = 5), "\n"))
cat(paste("Coefficient of Determination (R²):", round(r_squared, 4), "\n"))

if (p_value < 0.05) {
  cat("VERDICT: Reject the Null Hypothesis (H0). The correlation is Statistically Significant.\n")
} else {
  cat("VERDICT: Fail to Reject the Null Hypothesis (H0). The correlation is Not Statistically Significant.\n")
}

# ------------------------------------------------------------------------------
# STEP 4: Automated Serialization of Model Summaries (Phase 12 Pipeline Output)
# ------------------------------------------------------------------------------
# Capturing console model output and saving to disk automatically
sink("outputs/statistical_model_report.txt")
print(model_summary)
cat("\n--- Hypothesis Test Analysis Verification ---\n")
cat(paste("P-Value:", p_value, " | R-Squared:", r_squared, "\n"))
sink()

print("STATUS: Statistical text report generated and written to 'outputs/statistical_model_report.txt'.")