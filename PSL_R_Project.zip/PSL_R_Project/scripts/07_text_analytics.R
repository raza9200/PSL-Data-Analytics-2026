# ==============================================================================
# PROJECT: Pakistan Super League (PSL) Sports Analytics Pipeline
# MODULE: Text Analytics - Email, URL, Hashtag Extraction & Word Frequency Analysis
# ==============================================================================

library(tidyverse)
library(stringr)
library(tm)
library(wordcloud)

# Load the cleaned data state
if (file.exists("outputs/cleaned_state.RData")) {
  load("outputs/cleaned_state.RData")
} else {
  stop("FATAL ERROR: outputs/cleaned_state.RData not found. Please run your cleaning scripts first!")
}

cat("--- Beginning Text Analytics Operations ---\n")

# ==============================================================================
# 1. TEXT DATA PREPARATION
# ==============================================================================
cat("1. Preparing text data from player names and team names\n")

# Extract all unique player names
all_players <- psl_ball_final %>%
  distinct(striker, non_striker) %>%
  pivot_longer(cols = c(striker, non_striker), values_to = "player_name") %>%
  distinct(player_name) %>%
  filter(!is.na(player_name) & player_name != "None")

cat("Total unique players found:", nrow(all_players), "\n")
print(head(all_players))

# Extract all team names
all_teams <- psl_ball_final %>%
  distinct(batting_team, bowling_team) %>%
  pivot_longer(cols = c(batting_team, bowling_team), values_to = "team_name") %>%
  distinct(team_name) %>%
  filter(!is.na(team_name))

cat("\nTotal unique teams found:", nrow(all_teams), "\n")
print(all_teams)

# ==============================================================================
# 2. EMAIL EXTRACTION (simulated - since real data may not have emails)
# ==============================================================================
cat("\n2. Email extraction from text data\n")

# Create simulated data with emails for demonstration
simulated_player_data <- tibble(
  player_name = all_players$player_name,
  player_info = paste(player_name, "contact:", str_replace_all(str_to_lower(player_name), " ", "."), "@psl.com")
)

# Email extraction using regex
email_pattern <- "\\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}\\b"
simulated_player_data <- simulated_player_data %>%
  mutate(
    extracted_email = str_extract(player_info, email_pattern)
  )

cat("Email extraction results:")
print(head(simulated_player_data %>% select(player_name, player_info, extracted_email)))

# Count emails extracted
email_count <- sum(!is.na(simulated_player_data$extracted_email))
cat("\nEmails extracted:", email_count, "out of", nrow(simulated_player_data), "records\n")

# ==============================================================================
# 3. URL EXTRACTION (simulated - extracting from player info)
# ==============================================================================
cat("\n3. URL extraction from text data\n")

# Create simulated data with URLs
simulated_player_data <- simulated_player_data %>%
  mutate(
    player_info = paste(player_info, "Profile: https://psl.com/players/", str_replace_all(str_to_lower(player_name), " ", "-"))
  )

# URL extraction using regex
url_pattern <- "https?://[^\\s]+|www\\.[^\\s]+"
simulated_player_data <- simulated_player_data %>%
  mutate(
    extracted_url = str_extract(player_info, url_pattern)
  )

cat("URL extraction results:")
print(head(simulated_player_data %>% select(player_name, extracted_url)))

# Count URLs extracted
url_count <- sum(!is.na(simulated_player_data$extracted_url))
cat("\nURLs extracted:", url_count, "out of", nrow(simulated_player_data), "records\n")

# ==============================================================================
# 4. HASHTAG EXTRACTION (simulated - extracting from social media style text)
# ==============================================================================
cat("\n4. Hashtag extraction from text data\n")

# FIXED: Changed post_id from 1:20 to 1:21 to perfectly match the 21 text inputs below
social_media_data <- tibble(
  post_id = 1:21,
  post_text = c(
    "Great match by #BabarAzam today! #PSL2026 #Cricket",
    "#PSL final was amazing! #IslamabadUnited champions!",
    "#PSL2026 #Cricket #T20 #PakistanSuperLeague",
    "What a six by #ShadabKhan! #PSL #SixHitter",
    "#PSL2026 #Cricket #T20 #PakistanSuperLeague",
    "#PSL2026 #Cricket #T20 #PakistanSuperLeague",
    "#PSL2026 #Cricket #T20 #PakistanSuperLeague",
    "#PSL2026 #Cricket #T20 #PakistanSuperLeague",
    "#PSL2026 #Cricket #T20 #PakistanSuperLeague",
    "#PSL2026 #Cricket #T20 #PakistanSuperLeague",
    "#PSL2026 #Cricket #T20 #PakistanSuperLeague",
    "#PSL2026 #Cricket #T20 #PakistanSuperLeague",
    "#PSL2026 #Cricket #T20 #PakistanSuperLeague",
    "#PSL2026 #Cricket #T20 #PakistanSuperLeague",
    "#PSL2026 #Cricket #T20 #PakistanSuperLeague",
    "#PSL2026 #Cricket #T20 #PakistanSuperLeague",
    "#PSL2026 #Cricket #T20 #PakistanSuperLeague",
    "#PSL2026 #Cricket #T20 #PakistanSuperLeague",
    "#PSL2026 #Cricket #T20 #PakistanSuperLeague",
    "#PSL2026 #Cricket #T20 #PakistanSuperLeague",
    "#PSL2026 #Cricket #T20 #PakistanSuperLeague"
  )
)

# Hashtag extraction
hashtag_pattern <- "#\\w+"
hashtags_extracted <- social_media_data %>%
  mutate(
    extracted_hashtags = str_extract_all(post_text, hashtag_pattern)
  ) %>%
  unnest(extracted_hashtags)

cat("Hashtag extraction results:")
print(head(hashtags_extracted))

# Count hashtags
hashtag_count <- hashtags_extracted %>%
  count(extracted_hashtags, sort = TRUE)

cat("\nTop hashtags found:")
print(head(hashtag_count))

# ==============================================================================
# 5. KEYWORD EXTRACTION from player names
# ==============================================================================
cat("\n5. Keyword extraction from player names\n")

# Extract common cricket-related keywords
cricket_keywords <- c("Khan", "Ahmed", "Ali", "Malik", "Akmal", "Rizwan", "Babar", "Shadab", "Hafeez", "Wasim")

keyword_extraction <- all_players %>%
  mutate(
    contains_keyword = str_detect(player_name, paste(cricket_keywords, collapse = "|"))
  )

cat("Keyword extraction results:")
print(head(keyword_extraction %>% select(player_name, contains_keyword)))

keyword_count <- sum(keyword_extraction$contains_keyword)
cat("\nPlayer names containing cricket keywords:", keyword_count, "out of", nrow(keyword_extraction), "\n")

# ==============================================================================
# 6. WORD FREQUENCY ANALYSIS on player names
# ==============================================================================
cat("\n6. Word frequency analysis on player names\n")

# Create corpus from player names
player_corpus <- Corpus(VectorSource(all_players$player_name))

# Clean and process text
player_corpus <- tm_map(player_corpus, content_transformer(tolower))
player_corpus <- tm_map(player_corpus, removePunctuation)
player_corpus <- tm_map(player_corpus, removeNumbers)
player_corpus <- tm_map(player_corpus, stripWhitespace)

# Create document-term matrix
dtm <- DocumentTermMatrix(player_corpus)

# FIXED: Converted matrix extraction safely to prevent dimension-reduction errors in tm package
word_matrix <- as.matrix(dtm)
word_sums <- colSums(word_matrix)
word_freq_df <- data.frame(word = names(word_sums), total = word_sums, row.names = NULL) %>%
  arrange(desc(total))

# Get top 20 most frequent words
top_20_words <- head(word_freq_df, 20)

cat("Top 20 most frequent words in player names:\n")
print(top_20_words)

# Save word frequency results
write_csv(top_20_words, "outputs/player_name_word_frequency.csv")

# ==============================================================================
# 7. TEXT ANALYTICS VISUALIZATION
# ==============================================================================
cat("\n7. Creating text analytics visualizations\n")

dir.create("visualizations", showWarnings = FALSE)

# Create word frequency plot
word_freq_plot <- top_20_words %>%
  ggplot(aes(x = reorder(word, total), y = total)) +
  geom_bar(stat = "identity", fill = "#1a365d") +
  coord_flip() +
  labs(title = "Top 20 Words in PSL Player Names", 
       x = "Word", y = "Frequency") +
  theme_minimal()

# Save word frequency plot
ggsave("visualizations/word_frequency_analysis.png", plot = word_freq_plot, width = 10, height = 6, dpi = 300)

# Create hashtag frequency plot
hashtag_freq_plot <- hashtag_count %>%
  ggplot(aes(x = reorder(extracted_hashtags, n), y = n)) +
  geom_bar(stat = "identity", fill = "#2b6cb0") +
  coord_flip() +
  labs(title = "Top PSL Hashtags from Social Media", 
       x = "Hashtag", y = "Frequency") +
  theme_minimal()

# Save hashtag frequency plot
ggsave("visualizations/hashtag_frequency_analysis.png", plot = hashtag_freq_plot, width = 10, height = 6, dpi = 300)

# Create word cloud directly onto output device to ensure rendering safety
png("visualizations/player_wordcloud.png", width = 800, height = 800, res = 150)
wordcloud(words = top_20_words$word, freq = top_20_words$total,
          min.freq = 1, max.words = 20, random.order = FALSE,
          colors = brewer.pal(8, "Dark2"))
dev.off()

# Save frequency data instead of crashing on ggwordcloud missing functions
write_csv(top_20_words, "outputs/wordcloud_data.csv")

# ==============================================================================
# 8. TEXT ANALYTICS SUMMARY REPORT
# ==============================================================================
cat("\n8. Generating text analytics summary report\n")

text_analytics_summary <- tibble(
  analysis_type = c(
    "Email Extraction",
    "URL Extraction", 
    "Hashtag Extraction",
    "Keyword Extraction",
    "Word Frequency Analysis"
  ),
  items_found = c(
    email_count,
    url_count,
    nrow(hashtag_count),
    keyword_count,
    nrow(top_20_words)
  ),
  description = c(
    "Extracted email addresses from player information",
    "Extracted URLs from player profile data",
    "Extracted hashtags from simulated social media posts",
    "Identified cricket-related keywords in player names",
    "Analyzed word frequency in player names"
  )
)

cat("Text Analytics Summary:\n")
print(text_analytics_summary)

# Save text analytics summary
write_csv(text_analytics_summary, "outputs/text_analytics_summary.csv")

cat("\n--- Text Analytics Operations Complete ---\n")
cat("Results saved successfully to /outputs/ and /visualizations/\n")